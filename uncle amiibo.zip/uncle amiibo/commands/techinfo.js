module.exports = {
    name: 'techinfo',

    execute(interaction) {
        let tech = interaction.options.get('technique');
    }
}